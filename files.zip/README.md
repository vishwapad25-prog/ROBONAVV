# RoboNav

A simple, student-friendly robot control dashboard (demo). Plain HTML, CSS and JavaScript. No build step, no dependencies.

## Features
- Live map (2D and 3D) built from the robot's saved map
- Obstacle-aware routing (A* on a grid): the robot drives around walls
- Go To Location, with add and delete for your own places (saved in the browser)
- Manual drive: hold the arrow buttons or arrow keys
- Voice assistant (Chrome or Edge): "Go to Home", "Send to charging", "Save this spot as Lab Door", "Stop"
- Light and dark theme, Student and Engineer modes

## Files
```
index.html        page structure
css/style.css     all styles
js/app.js         map, routing, drive, voice
assets/           map images (floor.png, edge.png, top.png)
.nojekyll         tells GitHub Pages to serve files as they are
```

## Run locally
Open `index.html` in a browser. For the microphone to work, use a local server instead:
```
python3 -m http.server 8000
```
then open http://localhost:8000

## Deploy on GitHub Pages
1. Create a new repository on GitHub and upload all of these files (keep the folders).
2. Go to **Settings > Pages**.
3. Under **Build and deployment**, set **Source** to **Deploy from a branch**, choose **main** and **/ (root)**, then **Save**.
4. After a minute your site is live at `https://<your-username>.github.io/<repo-name>/`.

The microphone needs HTTPS, which GitHub Pages provides.

## Notes
- This is a simulation. The robot, battery and status values are demo data and are not connected to ROS yet.
- To use a different map, replace the three images in `assets/` and the grid string in `js/app.js`.
